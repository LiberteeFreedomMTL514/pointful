## Version 0.2.1.0 (2018-10-01)

- Replace DEPRECATED pragma for startClr and stopClr with a WARNING pragma ([#22][22], [@moodmosaic][moodmosaic])

[moodmosaic]:
  https://gitlab.com/moodmosaic

[22]:
  https://gitlab.com/tim-m89/clr-haskell/merge_requests/22

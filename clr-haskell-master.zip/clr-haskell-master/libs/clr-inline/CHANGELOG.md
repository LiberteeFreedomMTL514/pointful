# Revision history for clr-inline

## 0.2.0  -- 2017-08-05
* Experimental support for Haskell lambdas in the F# backend.

## 0.1.0.0  -- 2017-04-25

* First version. Released on an unsuspecting world.
